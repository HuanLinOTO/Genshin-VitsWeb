# Visuall Studio2019 安装教程
## Step 1
[点这下载](https://download.visualstudio.microsoft.com/download/pr/6d7709aa-465b-4604-b797-3f9c1d911e67/c4cbd4106b2b6ebd5e88e75d025b0ecbea6600d458ec1a8a795fe2212b3d9f8e/vs_Community.exe)

## Step 2
跟着步骤走

## Step 3
到这一步的时候按照图上的选 可以改安装目录
![vsi](docs/vsi.png)