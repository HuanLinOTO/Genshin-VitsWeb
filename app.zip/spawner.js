import inquirer from "inquirer";
inquirer.prompt([{
    type: 'input',
    name: 'miniconda_path',
    message: '请输入你想要把miniconda安装到哪个目录',
    default: 'D:/Miniconda3'
}]).then((answers) => { console.log('结果为:') ;console.log(answers)})