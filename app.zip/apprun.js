import axios from "axios";
import { spawn } from "child_process";
import { statSync, mkdirSync, createWriteStream } from "fs";
import { query } from 'windows-shortcuts';  
import { chdir, exit } from "process";
import { clearInterval } from "timers";
import inquirer from 'inquirer'
import fs from 'fs'
var conda = null;

function conda_send(sts,callback) {
    conda.stdin.write(sts+" \n");
    if(callback) callback();
}
function activate_conda(callback) {
    var minicondascript_path = "C:"+process.env.HOMEPATH+'\\AppData\\Roaming\\Microsoft\\Windows\\Start Menu\\Programs\\Anaconda3 (64-bit)'
    try {
        fs.statSync(minicondascript_path)
        minicondascript_path += "\\Anaconda Prompt (MINICONDA).lnk"
    } catch(Eaaa) {
        minicondascript_path = "C:\\ProgramData\\Microsoft\\Windows\\Start Menu\\Programs\\Anaconda3 (64-bit)\\Anaconda Prompt (MINICONDA).lnk"
    }
    query(minicondascript_path, function (err, lnk) {
        if(err) {
            console.log("miniconda路径获取失败！请开一个issue告诉作者");

            exit(1)
        }
        miniconda_path = lnk.args.split(" ")[2];
        console.log("获取成功 路径为",miniconda_path);
        callback();
    });
    console.log('cmd',["/K",miniconda_path+'\\Scripts\\activate.bat' ,miniconda_path]);
    conda = spawn('cmd',["/K",miniconda_path+'\\Scripts\\activate.bat' ,miniconda_path],{
        stdio: 'pipe'
      });
    conda.stdout.on("data",(data)=>{
        var content = data.toString()
        console.log(content);
    })
    conda.stderr.on("data",(data)=>{
        var content = data.toString()
        console.log(content);
    })

    conda_send("conda activate genshin-vitsweb")
    conda_send("node app.js")

    // callback()
}
activate_conda()